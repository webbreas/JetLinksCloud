import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import baimoImg from '@/assets/白模-白底.png';
import cameraIcon from '@/assets/摄像头.png';

interface CameraData {
  id: number;
  name: string;
  description: string;
  position: { top: string; left: string };
}

const cameraData: CameraData[] = [
  {
    id: 1,
    name: '画面与回放',
    description: '支持1/4/9布局看实时画面、看边缘回放，还可选择不同视频源保存监控墙。',
    position: { top: '25%', left: '15%' },
  },
  {
    id: 2,
    name: '说话的方式查监控',
    description: '无需人工盯着屏幕，直接告诉系统"查找刚才的异常片段"，AI自动为您打包证据。',
    position: { top: '40%', left: '50%' },
  },
  {
    id: 3,
    name: '告警时刻秒级回溯',
    description: '告警时间自动对齐视频录像，无需人工反复拖拽进度条，一键查看事发前后证据。',
    position: { top: '35%', left: '75%' },
  },
  {
    id: 4,
    name: '合规归档省心省力',
    description: '重要证据自动分类存储，轻松应对合规审计与事后追责，查找历史记录清晰便捷。',
    position: { top: '60%', left: '30%' },
  },
];

export default function Video() {
  const [selectedCamera, setSelectedCamera] = useState<CameraData | null>(null);
  const [hoveredCamera, setHoveredCamera] = useState<number | null>(null);

  const handleCameraClick = (camera: CameraData) => {
    setSelectedCamera(selectedCamera?.id === camera.id ? null : camera);
  };

  const handleClosePopup = () => {
    setSelectedCamera(null);
  };

  return (
    <section className="relative py-32 px-6 overflow-hidden bg-white">
      <div className="max-w-7xl mx-auto bg-white rounded-3xl">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            会说话的 <span className="text-gradient">视频中台</span>
          </h2>

          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            告警秒级回溯，AI 自动打包证据，让视频从此不再是死档案
          </p>
        </motion.div>

        <motion.div
          className="relative max-w-5xl mx-auto"
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-blue-500/10">
            <img
              src={baimoImg}
              alt="2.5D 房屋结构图"
              className="w-full h-auto"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-blue-50/30 via-transparent to-transparent" />

            {cameraData.map((camera) => (
              <motion.div
                key={camera.id}
                className="absolute cursor-pointer z-20"
                style={{ top: camera.position.top, left: camera.position.left }}
                initial={{ scale: 0, opacity: 0 }}
                whileInView={{ scale: 1, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: camera.id * 0.1 }}
                whileHover={{ scale: 1.2 }}
                onHoverStart={() => setHoveredCamera(camera.id)}
                onHoverEnd={() => setHoveredCamera(null)}
                onClick={() => handleCameraClick(camera)}
              >
                <div className={`relative flex items-center justify-center w-12 h-12 rounded-full transition-all duration-300 ${
                  hoveredCamera === camera.id || selectedCamera?.id === camera.id
                    ? 'bg-blue-500 shadow-lg shadow-blue-500/50'
                    : 'bg-white shadow-lg border-2 border-blue-400'
                }`}>
                  <img 
                    src={cameraIcon}
                    alt="摄像头"
                    className="w-6 h-6"
                  />
                  <motion.div
                    className={`absolute inset-0 rounded-full ${
                      hoveredCamera === camera.id || selectedCamera?.id === camera.id
                        ? 'bg-blue-400'
                        : 'bg-blue-300'
                    }`}
                    animate={{
                      scale: [1, 1.5, 1],
                      opacity: [0.5, 0, 0.5],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: 'easeOut',
                    }}
                  />
                </div>
              </motion.div>
            ))}
          </div>

          <AnimatePresence>
            {selectedCamera && (
              <motion.div
                className="absolute z-30 pointer-events-none"
                style={{
                  top: selectedCamera.position.top,
                  left: selectedCamera.position.left,
                }}
                initial={{ opacity: 0, y: 20, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                transition={{ duration: 0.5, ease: [0.25, 0.1, 0.25, 1] }}
              >
                <div className="relative ml-16 mt-8">
                  <div className="absolute -left-3 top-6 w-6 h-6 bg-white rotate-45 border border-gray-100" />
                  <div className="relative bg-white rounded-2xl shadow-2xl shadow-gray-200 p-6 w-xs max-w-xs min-w-[280px] border border-gray-100 pointer-events-auto" style={{ minHeight: '240px' }}>
                    <div className="absolute inset-0 rounded-2xl overflow-hidden opacity-10">
                      <img 
                        src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=300&h=200&fit=crop" 
                        alt="background" 
                        className="w-full h-full object-cover" 
                      />
                    </div>
                    <div className="relative">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center">
                            <img 
                              src={cameraIcon}
                              alt="摄像头"
                              className="w-4 h-4"
                            />
                          </div>
                          <h3 className="font-semibold text-gray-900">{selectedCamera.name}</h3>
                        </div>
                        <button
                          onClick={handleClosePopup}
                          className="p-1 hover:bg-gray-100 rounded-full transition-colors"
                        >
                          <X className="w-4 h-4 text-gray-400" />
                        </button>
                      </div>
                      <p className="text-sm text-gray-600 leading-relaxed">
                        {selectedCamera.description}
                      </p>
                      <div className="mt-4 pt-4 border-t border-gray-100">
                        <span className="text-xs text-blue-600 font-medium">下一个</span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

      </div>
    </section>
  );
}
