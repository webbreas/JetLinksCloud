import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { iotFeatures } from '@/data/content';
import { Map, Monitor, ClipboardList, Building, Activity } from 'lucide-react';

const iconMap: Record<string, React.ElementType> = {
  '🗺️': Map,
  '📊': Monitor,
  '📝': ClipboardList,
  '🏢': Building,
  '🔧': Activity,
};

export default function IoT() {
  const [activeIndex, setActiveIndex] = useState(0);
  const activeFeature = iotFeatures[activeIndex];

  return (
    <section className="relative py-32 px-6 overflow-hidden bg-white">
      <div className="relative z-10 max-w-7xl mx-auto">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            从十台到 <span className="text-gradient">千万台设备</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            一张地图、一屏掌控，按区域直观管理资产，让设备管理不再有盲区
          </p>
        </motion.div>

        <div className="bg-white rounded-3xl shadow-xl shadow-teal-500/10 overflow-hidden border border-gray-100">
          <div className="flex flex-wrap border-b border-gray-200 bg-gray-50">
            {iotFeatures.map((feature, idx) => {
              const Icon = iconMap[feature.icon] || Map;
              return (
                <div
                  key={idx}
                  onClick={() => setActiveIndex(idx)}
                  className={`flex-1 min-w-[200px] px-6 py-5 flex items-center justify-center gap-3 transition-all duration-300 border-b-2 cursor-pointer ${
                    activeIndex === idx
                      ? 'border-teal-500 bg-white text-teal-600'
                      : 'border-transparent text-gray-500 hover:bg-gray-50 hover:text-gray-700'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium whitespace-nowrap">{feature.title}</span>
                </div>
              );
            })}
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={activeIndex}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
              className="p-8 lg:p-12"
            >
              <div className="text-center mb-8">
                <h3 className="text-3xl font-bold text-gray-900 mb-3">
                  {activeFeature.title}
                </h3>
                <p className="text-lg text-gray-600 leading-relaxed max-w-2xl mx-auto">
                  {activeFeature.desc}
                </p>
              </div>

              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="relative rounded-2xl overflow-hidden shadow-2xl h-[400px]"
              >
                <div className="absolute inset-0 bg-gradient-to-t from-teal-900/40 via-transparent to-transparent z-10" />
                <img
                  src={activeFeature.image}
                  alt={activeFeature.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-6 left-6 z-20">
                  <span className="px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full text-white text-sm font-medium">
                    {activeFeature.title}
                  </span>
                </div>
              </motion.div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
