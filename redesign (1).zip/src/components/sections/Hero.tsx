import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FileText, Tag } from 'lucide-react';
import HeroBg from '@/assets/首屏.png';

export default function Hero() {
  const [isFlipped, setIsFlipped] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsFlipped(prev => !prev);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0">
        <img 
          src={HeroBg}
          alt="Background" 
          className="w-full h-full object-cover"
        />
      </div>

      <div className="relative z-10 text-center max-w-5xl mx-auto px-6">
        <motion.h1
          className="text-[2.08rem] md:text-[4.8rem] font-bold leading-tight -mt-[66px] mb-3"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <span className="text-black drop-shadow-lg">连接无界</span>
          <br />
          <div className="inline-block overflow-hidden">
            <AnimatePresence mode="wait">
              <motion.span
                key={isFlipped ? 'evolve' : 'reach'}
                className="text-gradient inline-block"
                initial={{ rotateX: -90, opacity: 0 }}
                animate={{ rotateX: 0, opacity: 1 }}
                exit={{ rotateX: 90, opacity: 0 }}
                transition={{ duration: 0.6, ease: [0.25, 0.1, 0.25, 1] }}
                style={{ transformStyle: 'preserve-3d', backfaceVisibility: 'hidden' }}
              >
                {isFlipped ? '智慧进化' : '触手可及'}
              </motion.span>
            </AnimatePresence>
          </div>
        </motion.h1>

        <motion.p
          className="text-base md:text-lg max-w-3xl mx-auto leading-relaxed mb-4"
          style={{ color: '#475569', marginTop: '10px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          告别繁琐开发，提供全链路SaaS服务，按需订阅，零代码快速构建，助力企业极速释放数据价值
        </motion.p>

        <motion.div
          className="flex justify-center"
          style={{ marginTop: '20px' }}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
        >
          <motion.button
            className="px-[47px] py-4 bg-gradient-to-r from-blue-500/80 to-blue-600/80 backdrop-blur-md border border-white/30 text-white font-semibold hover:shadow-xl hover:shadow-blue-500/50 transition-all"
            style={{ borderRadius: '45px', fontSize: '1.3rem' }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            立即体验
          </motion.button>
        </motion.div>

        <motion.div
          className="mt-5 flex items-center justify-center gap-4"
          style={{ color: '#475569' }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.2 }}
        >
          <a
            href="#"
            className="flex items-center gap-2 hover:opacity-70 transition-opacity"
          >
            <FileText className="w-5 h-5" style={{ color: '#475569' }} />
            <span>查看文档</span>
          </a>
          <div className="w-px h-4 bg-gray-300" />
          <a
            href="#"
            className="flex items-center gap-2 hover:opacity-70 transition-opacity"
          >
            <Tag className="w-5 h-5" style={{ color: '#475569' }} />
            <span>查看定价</span>
          </a>
        </motion.div>
      </div>
    </section>
  );
}
