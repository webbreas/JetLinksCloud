import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { aiFeatures } from '@/data/content';
import { CheckCircle } from 'lucide-react';

export default function AI() {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const selectedFeature = aiFeatures[selectedIndex];

  return (
    <section className="relative py-32 px-6 overflow-hidden bg-gradient-to-b from-blue-50 via-white to-blue-50">
      <div className="relative z-10 max-w-7xl mx-auto">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            打造工业级 <span className="text-gradient">全链路AI引擎</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            从一句话生成业务系统，到训练自己的AI模型，AI 贯穿整个SaaS平台
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="bg-white rounded-3xl shadow-2xl shadow-blue-500/10 border border-gray-200 overflow-hidden"
        >
          <div className="grid lg:grid-cols-3 min-h-[600px]">
            <div className="lg:col-span-1 border-r border-gray-200 bg-gray-50/50">
              {aiFeatures.map((feature, idx) => (
                <div key={idx}>
                  <motion.div
                    onClick={() => setSelectedIndex(idx)}
                    className={`px-6 py-6 cursor-pointer transition-all duration-300 ${
                      selectedIndex === idx
                        ? 'bg-gradient-to-r from-blue-500 to-blue-600'
                        : 'hover:bg-gray-100'
                    }`}
                    whileHover={{ x: 4 }}
                  >
                    <div className="flex items-center gap-4">
                      <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-white/20">
                        <span className="text-2xl">{feature.icon}</span>
                      </div>
                      <div className="flex-1">
                        <h3 className={`font-bold text-lg ${
                          selectedIndex === idx ? 'text-white' : 'text-gray-900'
                        }`}>
                          {feature.title}
                        </h3>
                        <p className={`text-sm mt-1 ${
                          selectedIndex === idx ? 'text-white/80' : 'text-gray-500'
                        }`}>
                          {feature.desc}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                  {idx < aiFeatures.length - 1 && (
                    <div className="h-px bg-gray-200 mx-6" />
                  )}
                </div>
              ))}
            </div>

            <div className="lg:col-span-2 flex flex-col">
              <AnimatePresence mode="wait">
                <motion.div
                  key={selectedIndex}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5 }}
                  className="flex-1 flex flex-col"
                >
                  <div className="relative flex-[4] overflow-hidden">
                    <img
                      src={selectedFeature.image}
                      alt={selectedFeature.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-black/20 to-transparent" />
                    <div className="absolute bottom-6 left-6">
                      <span className="px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full text-white text-lg font-medium">
                        {selectedFeature.title}
                      </span>
                    </div>
                  </div>

                  <div className="flex-[1] p-6 bg-white">
                    <div className="grid grid-cols-2 gap-4">
                      {selectedFeature.details.map((detail, idx) => (
                        <motion.div
                          key={idx}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.3, delay: idx * 0.1 }}
                          className="flex items-start gap-3 p-4 rounded-xl bg-gray-50 hover:bg-blue-50 transition-colors"
                        >
                          <CheckCircle className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-600 leading-relaxed text-sm">{detail}</span>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
